import { Bot, FileText, Eye, TrendingUp, Database, BarChart3 } from 'lucide-react';

export const services = [
  {
    icon: Bot,
    title: "AI Customer Support Chatbot",
    tech: "FastAPI + OpenAI + React + WebSocket",
    description: "Reduce customer service costs by 70% with intelligent WhatsApp chatbots",
    demo: "chatbot"
  },
  {
    icon: FileText,
    title: "Document Processing AI",
    tech: "Python + spaCy + NLTK + TextBlob + FastAPI",
    description: "Process 1000+ documents hourly with 95% accuracy using advanced NLP",
    demo: "document"
  },
  // ... rest of the services
];